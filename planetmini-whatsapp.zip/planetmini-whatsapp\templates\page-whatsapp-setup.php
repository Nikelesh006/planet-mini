<?php
/**
 * Template Name: WhatsApp Embedded Signup Setup
 * Description: Page template for WhatsApp Embedded Signup v4
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WhatsApp Business Setup - Planetmini</title>
    <link rel="stylesheet" href="<?php echo esc_url(PLANETMINI_WA_URL . 'assets/css/setup.css'); ?>">
</head>
<body>
    <div class="setup-container">
        <div class="setup-header">
            <div class="setup-logo">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#25D366" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
                </svg>
            </div>
            <h1>Connect WhatsApp Cloud API</h1>
            <p class="subtitle">Onboard your WhatsApp Business Account (WABA) for automated WooCommerce admin order alerts on planetmini.in.</p>
        </div>

        <div class="setup-card">
            <div class="details-list">
                <div class="detail-item">
                    <span class="label">Store:</span>
                    <span class="val">Planetmini - Baby and Toddler wear</span>
                </div>
                <div class="detail-item">
                    <span class="label">Meta App ID:</span>
                    <span class="val"><?php echo esc_html(PLANETMINI_WA_APP_ID); ?></span>
                </div>
                <div class="detail-item">
                    <span class="label">Config ID:</span>
                    <span class="val"><?php echo esc_html(PLANETMINI_WA_CONFIG_ID); ?></span>
                </div>
                <div class="detail-item">
                    <span class="label">Graph API:</span>
                    <span class="val"><?php echo esc_html(PLANETMINI_WA_GRAPH_VERSION); ?></span>
                </div>
                <div class="detail-item">
                    <span class="label">Admin Alert Target:</span>
                    <span class="val">+<?php echo esc_html(PLANETMINI_WA_ADMIN_PHONE); ?></span>
                </div>
            </div>

            <div id="status-container" class="status-container" style="display: none;">
                <div id="status-spinner" class="spinner"></div>
                <p id="status-message">Waiting for authentication...</p>
            </div>

            <button id="btn-whatsapp-signup" class="btn-facebook" onclick="launchWhatsAppSignup()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
                Continue with Facebook
            </button>

            <div class="setup-footer">
                <a href="<?php echo esc_url(admin_url('admin.php?page=planetmini-whatsapp')); ?>">Back to WordPress Admin</a>
            </div>
        </div>
    </div>

    <!-- Pass configuration to JS -->
    <script>
        window.PLANETMINI_WA_CONFIG = {
            appId: '<?php echo esc_js(PLANETMINI_WA_APP_ID); ?>',
            configId: '<?php echo esc_js(PLANETMINI_WA_CONFIG_ID); ?>',
            graphVersion: '<?php echo esc_js(PLANETMINI_WA_GRAPH_VERSION); ?>',
            restUrl: '<?php echo esc_url(rest_url('planetmini/v1/whatsapp/exchange')); ?>',
            adminUrl: '<?php echo esc_url(admin_url('admin.php?page=planetmini-whatsapp')); ?>'
        };
    </script>

    <!-- Facebook SDK v26.0 -->
    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js"></script>
    <script src="<?php echo esc_url(PLANETMINI_WA_URL . 'assets/js/embedded-signup.js'); ?>"></script>
</body>
</html>
